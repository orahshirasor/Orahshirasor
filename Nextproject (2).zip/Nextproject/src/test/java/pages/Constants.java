package pages;

public class Constants {
    public static final String URL_GARDEN= "gardenandoutdoors";
    public static final String URL_LIVINGROOM= "https://www.next.co.il/en/shop/department-homeware-productaffiliation-livingroom-0";
    public static final String URL_CHLIDRENSBEDROOM = "https://www.next.co.il/en/shop/department-homeware-productaffiliation-childrensbedroom-0";

    public static final String URL_CHANGELANGUAGE ="https://www.next.co.il/en";

    public static final String URL_SEARCHBOX = "https://www.next.co.il/en/search?w=shirt";

    public static final String URL_CHOOSEPRODUCT = "https://www.next.co.il/en/search?w=shirt&p=1#400";

    public static final String URL_ADDTOBAG = "https://www.next.co.il/en/style/st274082/c31719#c31719";

    public static final String URL_CHECKOUT = "https://account.next.co.il/en/login/Checkout";
    public static final String URL_PAYMENTPAGE = "https://www.next.co.il/en/secure/checkout/payment?bagChanged=False";







}

