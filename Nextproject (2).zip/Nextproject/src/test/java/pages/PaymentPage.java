package pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PaymentPage {

    private final WebDriver driver;

    //הגדרת כפתור ללחיצה

    By creditDebitCard = By.xpath("//*[@id=\"PaymentId\"]");
    By cardNumber = By.xpath("//*[@id=\"cardNumber\"]");

    By expiryDateMonth = By.xpath("//*[@id=\"expiryMonth\"]");

    By expiryDateYear = By.xpath("//*[@id=\"expiryYear\"]");

    By securityCode = By.xpath("//*[@id=\"securityCode\"]");

    By payNow = By.xpath("//*[@id=\"submitButton\"]");


    public PaymentPage(WebDriver driver) {
        this.driver = driver;
    }

    //פונקציית בחירת שיטת תשלום

    public void credit() throws InterruptedException {

        driver.findElement(creditDebitCard).click();
        Thread.sleep(3000);


    }

    //פונקציית הזנת פרטי תשלום

    public void cardNumber() throws InterruptedException {
        driver.findElement(cardNumber).sendKeys();
        Thread.sleep(3000);


    }
   //תאריך תפוגה חודש
    public void expiryDateMonth() throws InterruptedException {
        driver.findElement(expiryDateMonth).sendKeys();
        Thread.sleep(3000);
    }
    //תאריך תפגה שנה
    public void expiryDateYear() throws InterruptedException {
        driver.findElement(expiryDateYear).sendKeys();
        Thread.sleep(3000);
    }
    //קוד אבטחה
    public void securityCode() throws InterruptedException {
        driver.findElement(securityCode).sendKeys();
        Thread.sleep(3000);


    }
    //שלם עכשיו
    public void payNow() throws InterruptedException {
        driver.findElement(payNow).sendKeys();
        Thread.sleep(3000);

    }

}



