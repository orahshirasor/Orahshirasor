package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {

    WebDriver driver;

    By myaccountlocator = By.xpath("//*[@id=\"platform_modernisation_header\"]/header/div[1]/nav/div[4]/div[2]/div/a/span");
    By emailLocator = By.id("EmailOrAccountNumber");

    By myPassword = By.xpath("//*[@id=\"Password\"]");

    By signing = By.xpath("//*[@id=\"SignInNow\"]");

    By errorMessageLocator=By.xpath("//*[@id=\"pri\"]/div/div/div/div/div/div");

    public LoginPage(WebDriver driver) {
        this.driver = driver;

    }

    public void clickMyAccount() {
        driver.findElement(myaccountlocator).click();

    }

    public void enterEmail(String mail) {
        driver.findElement(emailLocator).sendKeys(mail);

    }

    public void setMyPassword(String password) {
        driver.findElement(myPassword).sendKeys(password);

    }
    public void clicksigning(){
        driver.findElement(signing).click();


    }
    //פונקציה המחזירה האם הודעת השגיאה תופיע
    public boolean errorMessage() {
        boolean message=false;
        WebElement messageElement= driver.findElement(errorMessageLocator);

        if (messageElement.isDisplayed()){
            message=true;
        }
        else {
            message= false;
        }
        return message;
    }

}
