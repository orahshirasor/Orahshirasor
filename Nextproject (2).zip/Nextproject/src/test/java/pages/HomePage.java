package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {


    WebDriver driver;

    //הגדרת כפתור ללחיצה
    By homePage = By.xpath("//*[@id=\"meganav-link-6\"]/div");
    By gardenLeft = By.xpath("*[@id=\"left-sidebar-links7-8wewfepnptpg32ipi81u7raca\"]");
    By middlePageLRoom = By.cssSelector("[title='Living Room']");
    private By emailLocator;
    //הבאנר שלי
    By childrensBedroom = By.xpath("//*[@id=\"Three-Teaser-Stack2_slide_2\"]/div/a/div[2]/h3");
    By clickChangeLanguage1 = By.xpath("//*[@id=\"platform_modernisation_header\"]/header/div[1]/nav/div[9]/button/img");
    //By clickSearchBox = By.xpath("//*[@id=\"header-search-form\"]/button");
    By clickSearchBox = By.cssSelector("#header-big-screen-search-box");

    By buttonClickSearchBox = By.xpath("//*[@id=\"header-search-form\"]/button/img") ;
    //By buttonClickSearchBox = By.xpath("//*[@id=\"platform_modernisation_product_summary_C24385\"]/div/div[1]/div[1]/div/div/div[1]/a/img") ;


    public HomePage(WebDriver driver) {

        this.driver = driver;
    }

    public void clickHomePage() {
        driver.findElement(homePage).click();


    }

    //פונקציה הבודקת האם URL זהים והטסט עבר
    public void clickGardenLeft() {

        driver.findElement(gardenLeft);
    }




        //כניסה לקישור קטגוריית במרכז עמוד (חזור לדף הבית)

        public void clickLivigRoomMiddle() {
            driver.findElement(middlePageLRoom).click();

        }
       // כניסה לבאנר וחזרה לדף הבית

        public void clickChildrensBedroom ()
        {
        driver.findElement(childrensBedroom).click();
        }
        //שינוי שפה

        public void clickChangeLanguage () {
            driver.findElement(clickChangeLanguage1).click();
        }



        //חיפוש מוצר בדף חיפוש
        public void sendKeySearchBox1()  {
        driver.findElement(clickSearchBox).sendKeys("shirt");
        driver.findElement(buttonClickSearchBox).click();
    }
}










