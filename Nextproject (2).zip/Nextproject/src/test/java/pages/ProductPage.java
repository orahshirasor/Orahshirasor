package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


//בכל דף מקבלת תדרייבר ומאתחלת לצורך מציאת האלמנט
public class ProductPage {
    private final WebDriver driver;


    //הגדרת כפתור ללחיצה


    By chooseProduct = By.xpath("//*[@id=\"platform_modernisation_product_summary_C24385\"]/div/div[1]/div[1]/div/div/div[1]/a/img");


    By colorShirt = By.cssSelector("[id*='dk_container_Colour-']");
    //By colorShirt = By.cssSelector("#dk_container_Colour-128473");

    By blueColor = By.xpath("//*[@id=\"dk_container_Colour-128473\"]/div/ul/li[3]/a");
    By sizeShirt = By.cssSelector("[id*='dk_container_Size-']");

    By size3months=By.xpath("//*[@id=\"dk_container_Size-C82-049\"]/div/ul/li[2]/a");


    By addToBag = By.xpath("//*[@id=\"Style128473\"]/section/div[4]/div[5]/div[4]/div/a[1]");

    By shopingBag = By.xpath ("//*[@id=\"platform_modernisation_header\"]/header/div[1]/nav/div[7]/div[2]/a/div");

    By viewEditBag = By.xpath("//*[@id=\"platform_modernisation_header\"]/header/div[1]/nav/div[7]/div[2]/div/div/div[2]/div/div/div[3]/div[1]/a");

    By checkOut = By.xpath ("//*[@id=\"platform_modernisation_header\"]/header/div[1]/nav/div[8]/div/a");
    //בנאי
    public ProductPage(WebDriver driver) {
        this.driver = driver;

    }
    //פונקצית בחירת מוצר
    public void ChooseProduct(){

        driver.findElement(chooseProduct).click();
    }

    //פונקצית בחירת צבע
    public void checkColor() throws InterruptedException {
        driver.findElement(colorShirt).click();
        Thread.sleep(4000);
        driver.findElement(blueColor).click();

    }


    //פונקציית בחירת מידה
    public void chooseSize() throws InterruptedException {
        driver.findElement(sizeShirt).click();
        Thread.sleep(5000);
        driver.findElement(size3months).click();
    }

    //פונקצית הוסף לסל והוספת עוד פריט מאותו מוצר
    public void AddToBag() throws InterruptedException {
        driver.findElement(addToBag).click();
        Thread.sleep(3000);



    }

    //בדיקת סל הקניות

    public void ShopingBag() throws InterruptedException{
        driver.findElement(shopingBag).click();

    }

    public void ViewEditbag()throws InterruptedException{
        driver.findElement(shopingBag).click();
        Thread.sleep(3000);
        driver.findElement(viewEditBag).click();
        Thread.sleep(3000);

    }

    //
    public void CheckOut()  throws InterruptedException{
        driver.findElement(checkOut).click();
    }
}
