package testCases;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import org.apache.commons.io.FileUtils;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import pages.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.junit.*;

import static pages.Constants.*;


public class SanityTest {

    private static WebDriver driver;

    LoginPage loginPage = new LoginPage(driver);
    HomePage homePage = new HomePage(driver);

    ProductPage productPage = new ProductPage(driver);

    PaymentPage paymentPage= new PaymentPage(driver);

    // create ExtentReports and attach reporter(s)
    private static ExtentReports extent;

    // creates a toggle for the given test, adds all log events under it
    private static ExtentTest test;

    @BeforeClass
    public static void beforeClass() throws ParserConfigurationException, IOException, SAXException {
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("C:\\Users\\P0032928\\Desktop\\automation\\Nextproject\\Nextproject\\extent.html");

        // attach reporter
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
        // name your test and add description
        test = extent.createTest("SanityTest", "Sanity test for 'next' site");

        // add custom system info
        extent.setSystemInfo("Project Development Language: ", "Java");
        extent.setSystemInfo("Development Environment IDE: ", "IntelliJ idea");
        extent.setSystemInfo("Third Party Software: ", "Selenium WebDriver, Junit, ExtentReports, Maven");
        extent.setSystemInfo("URL: ", getData("URL"));
        extent.setSystemInfo("Tester", "Orah Shir - Asor");


        System.out.println("beforclass");
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\P0032928\\Desktop\\Drivers\\chromedriver.exe");
        driver = new ChromeDriver();

        driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        driver.get(getData("URL"));
    }

    //כניס לדף הבית לפני כל הרצת טסט
    @Before
    public void before() {
        //לחיצה כפולה
        Actions act = new Actions(driver);
        act.doubleClick(driver.findElement(By.xpath("//*[@id=\"meganav-link-6\"]")));
        act.build().perform();

    }


    //login

    @Test
    public void loginTest_01() throws InterruptedException, ParserConfigurationException, IOException, SAXException {
        loginPage.clickMyAccount();

        loginPage.enterEmail(getData("EMAIL"));
        Thread.sleep(Long.parseLong("5000"));
        loginPage.setMyPassword(getData("PASSWORD"));
        Thread.sleep(Long.parseLong("5000"));
        loginPage.clicksigning();
        boolean exceptedMessage = loginPage.errorMessage();
        if (exceptedMessage) {
            //test passed
        } else {
            //test failed
        }
        driver.navigate().to("https://www.next.co.il/en/homeware");
    }

    @Test

    public void homePageTest_02() throws IOException, InterruptedException {
        test.log(Status.INFO,"test home page ");
        homePage.clickHomePage();
        addScreenshot();
        Thread.sleep(3000);
        homePage.clickGardenLeft();
        addScreenshot();
        Thread.sleep(3000);
        validatePage("Garden", Constants.URL_GARDEN);
        //חזרה לדף ראשי
        driver.navigate().back();

    }

    //כניסה לקישור קטגוריית במרכז עמוד (חזור לדף הבית)
    @Test
    public void middlePageLRoomTest_03() throws IOException, InterruptedException {
        test.log(Status.INFO,"test middle page room");
        homePage.clickLivigRoomMiddle();
        addScreenshot();
        Thread.sleep(300);
        validatePage("living room",Constants.URL_LIVINGROOM);
        driver.navigate().back();

    }

    // כניסה לבאנר וחזרה לדף הבית
    @Test

    public void childrensBedroomTest_04() throws InterruptedException, IOException {
        test.log(Status.INFO,"test children bedroom");
        homePage.clickChildrensBedroom();
        addScreenshot();
        validatePage("children bedroom",Constants.URL_CHLIDRENSBEDROOM);
        Thread.sleep(2000);

    }

    //שינוי שפה
    @Test

    public void changeLanguageTest_05() throws InterruptedException, IOException {
        test.log(Status.INFO,"test change Language ");
        homePage.clickChangeLanguage();
        addScreenshot();
        Thread.sleep(3000);
       validatePage("ChangeLanguage",Constants.URL_CHANGELANGUAGE);

    }

    @Test

    //בדיקת מעבר לדף המוצר

    public void checkUrlTest00_() throws InterruptedException, IOException {
        test.log(Status.INFO,"test check url");
        homePage.sendKeySearchBox1();
        addScreenshot();
        Thread.sleep(3000);
       validatePage("shirt Product",URL_SEARCHBOX);


    }


    @Test

    //חיפוש מוצר בחירת מוצר מידה וצבע והוספה לסל והוספה נוספת מאותו מוצר
    public void SearchBox1Test_06() throws InterruptedException, IOException, ParserConfigurationException, SAXException {

        //מידע לדוח
        test.log(Status.INFO,"test search box starting");
        //
        homePage.sendKeySearchBox1();
        Thread.sleep(3000);
        productPage.ChooseProduct();
        addScreenshot();
        validatePage("shirt",URL_CHOOSEPRODUCT);
        Thread.sleep(3000);
        productPage.checkColor();
        addScreenshot();
        Thread.sleep(3000);
        productPage.chooseSize();
        addScreenshot();
        Thread.sleep(3000);
        addScreenshot();
        productPage.AddToBag();
        addScreenshot();
        Thread.sleep(3000);
        productPage.AddToBag();
        addScreenshot();
        Thread.sleep(3000);
        productPage.ShopingBag();
        addScreenshot();
        Thread.sleep(3000);
        productPage.ViewEditbag();
        validatePage("edit bag",URL_ADDTOBAG);
        addScreenshot();
        Thread.sleep(3000);
        productPage.CheckOut();
        addScreenshot();
        Thread.sleep(3000);
        driver.navigate().to(getData("URL"));
        //validatePage("check out",URL_CHECKOUT);


    }
    @Ignore
    @Test

   public void PaymentPage_07() throws InterruptedException {
          test.log(Status.INFO,"test payment page");
          paymentPage.credit();
          //addScreenshot();
          Thread.sleep(3000);
          //validatePage("payment page",URL_PAYMENTPAGE);
          paymentPage.cardNumber();
          //addScreenshot();
        Thread.sleep(3000);
          paymentPage.expiryDateMonth();
        //addScreenshot();
        Thread.sleep(3000);
          paymentPage.expiryDateYear();
        //addScreenshot();
        Thread.sleep(3000);
          paymentPage.securityCode();
        //addScreenshot();
        Thread.sleep(3000);
          paymentPage.payNow();
        //addScreenshot();
        Thread.sleep(3000);






           }


    @AfterClass
    public static void afterClass() {
        test.log(Status.INFO,"after class");
        System.out.println("afterclass");

        try {
            Thread.sleep(Long.parseLong("5000"));
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        extent.flush();
        driver.quit();

    }

    private void validatePage(String nameNewPage, String expectedUrl) throws InterruptedException, IOException {

        String actualUrl = driver.getCurrentUrl();
        boolean equalsUrl = actualUrl.equals(expectedUrl);
        addScreenshot();
        if (equalsUrl) {
            System.out.println("The transition to the web " + nameNewPage + " page was done successfully");
            test.log(Status.PASS, "The transition to the web " + nameNewPage + " page was done successfully ");
        } else {
            System.out.println("The transition to the web " + nameNewPage + " page was fail");
            test.log(Status.FAIL, "The transition to the web " + nameNewPage + " page was fail");
        }

    }

    //The method add screenshot
    public void addScreenshot() throws IOException {
        String currentTime = String.valueOf(System.currentTimeMillis());
        test.pass("details", MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot("C:\\Users\\P0032928\\Desktop\\automation\\Nextproject\\Nextproject\\" + currentTime)).build());
    }

    //A function required to add a screenshot
    private static String takeScreenShot(String ImagesPath) {
        TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
        File screenShotFile = takesScreenshot.getScreenshotAs(OutputType.FILE);
        File destinationFile = new File(ImagesPath + ".png");
        try {
            FileUtils.copyFile(screenShotFile, destinationFile);
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return ImagesPath + ".png";
    }


    //The method for reading from file //get data
    private static String getData(String keyName) throws ParserConfigurationException, IOException, SAXException {
        File configXmlFile = new File("C:\\Users\\P0032928\\Desktop\\automation\\Nextproject\\Nextproject\\config.xml");

        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = null;

        dBuilder = dbFactory.newDocumentBuilder();

        Document doc = null;

        /*assert dBuilder != null;
         doc = (Document) dBuilder.parse(configXmlFile);*/
        assert dBuilder != null;
        doc = (Document) dBuilder.parse(configXmlFile);

        if (doc != null) {
            ((org.w3c.dom.Document) doc).getDocumentElement().normalize();
        }
        assert doc != null;
        return ((org.w3c.dom.Document) doc).getElementsByTagName(keyName).item(0).getTextContent();
    }
}
